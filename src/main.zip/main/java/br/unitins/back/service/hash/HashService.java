package br.unitins.back.service.hash;

public interface HashService {

    public String getHashSenha(String senha);
}
