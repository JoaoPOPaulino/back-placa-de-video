package br.unitins.back.dto.request.pagamento;

public record GooglePayTokenDTO( 
    String type,
    String token
) {

}
