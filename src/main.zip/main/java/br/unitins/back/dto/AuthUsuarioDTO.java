package br.unitins.back.dto;

public record AuthUsuarioDTO(
        String login,
        String senha
        ) {

}
